import React from "react";
import SpeechUI from "./SpeechUI";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div>
      <SpeechUI />
    </div>
  );
}

export default App;
